<?php
// created: 2014-06-13 11:45:56
$dictionary["sel_Selkirk_Business_Case"]["fields"]["sel_selkirk_business_case_sel_selkirk_approvals"] = array (
  'name' => 'sel_selkirk_business_case_sel_selkirk_approvals',
  'type' => 'link',
  'relationship' => 'sel_selkirk_business_case_sel_selkirk_approvals',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Approvals',
  'bean_name' => 'sel_Selkirk_Approvals',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_BUSINESS_CASE_SEL_SELKIRK_APPROVALS_FROM_SEL_SELKIRK_APPROVALS_TITLE',
);

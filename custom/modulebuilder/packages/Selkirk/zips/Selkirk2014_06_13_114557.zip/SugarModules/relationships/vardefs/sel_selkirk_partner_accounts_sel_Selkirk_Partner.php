<?php
// created: 2014-06-05 22:50:56
$dictionary["sel_Selkirk_Partner"]["fields"]["sel_selkirk_partner_accounts"] = array (
  'name' => 'sel_selkirk_partner_accounts',
  'type' => 'link',
  'relationship' => 'sel_selkirk_partner_accounts',
  'source' => 'non-db',
  'module' => 'Accounts',
  'bean_name' => 'Account',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_PARTNER_ACCOUNTS_FROM_ACCOUNTS_TITLE',
);

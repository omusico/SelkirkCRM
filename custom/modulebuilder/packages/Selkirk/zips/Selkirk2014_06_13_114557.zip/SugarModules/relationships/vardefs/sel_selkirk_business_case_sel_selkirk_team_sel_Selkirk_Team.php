<?php
// created: 2014-06-13 11:45:56
$dictionary["sel_Selkirk_Team"]["fields"]["sel_selkirk_business_case_sel_selkirk_team"] = array (
  'name' => 'sel_selkirk_business_case_sel_selkirk_team',
  'type' => 'link',
  'relationship' => 'sel_selkirk_business_case_sel_selkirk_team',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Business_Case',
  'bean_name' => 'sel_Selkirk_Business_Case',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_BUSINESS_CASE_SEL_SELKIRK_TEAM_FROM_SEL_SELKIRK_BUSINESS_CASE_TITLE',
);

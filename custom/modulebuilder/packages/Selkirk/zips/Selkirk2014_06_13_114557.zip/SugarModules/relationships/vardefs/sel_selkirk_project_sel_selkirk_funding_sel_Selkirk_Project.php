<?php
// created: 2014-06-13 11:45:55
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_funding"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_funding',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_funding',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Funding',
  'bean_name' => 'sel_Selkirk_Funding',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_FUNDING_FROM_SEL_SELKIRK_FUNDING_TITLE',
);

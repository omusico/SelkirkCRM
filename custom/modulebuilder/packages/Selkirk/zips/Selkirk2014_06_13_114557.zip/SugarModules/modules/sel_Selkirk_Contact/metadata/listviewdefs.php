<?php
$module_name = 'sel_Selkirk_Contact';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'EMAIL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_EMAIL',
    'width' => '10%',
    'default' => true,
  ),
  'OFFICE_PHONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_OFFICE_PHONE',
    'width' => '10%',
    'default' => true,
  ),
  'CELL_PHONE' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_CELL_PHONE',
    'width' => '10%',
    'default' => true,
  ),
);
?>

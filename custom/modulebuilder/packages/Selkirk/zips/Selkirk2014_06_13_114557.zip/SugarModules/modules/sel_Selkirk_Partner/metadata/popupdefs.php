<?php
$popupMeta = array (
    'moduleMain' => 'sel_Selkirk_Partner',
    'varName' => 'sel_Selkirk_Partner',
    'orderBy' => 'sel_selkirk_partner.name',
    'whereClauses' => array (
  'partner' => 'sel_selkirk_partner.partner',
  'description' => 'sel_selkirk_partner.description',
),
    'searchInputs' => array (
  4 => 'partner',
  5 => 'description',
),
    'searchdefs' => array (
  'partner' => 
  array (
    'type' => 'relate',
    'studio' => 'visible',
    'label' => 'LBL_PARTNER',
    'id' => 'SEL_SELKIRK_CLIENT_ID_C',
    'link' => true,
    'width' => '10%',
    'name' => 'partner',
  ),
  'description' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'name' => 'description',
  ),
),
    'listviewdefs' => array (
  'DESCRIPTION' => 
  array (
    'type' => 'text',
    'label' => 'LBL_DESCRIPTION',
    'sortable' => false,
    'width' => '10%',
    'default' => true,
    'name' => 'description',
  ),
),
);

<?php
// created: 2014-06-13 11:46:05
$dictionary["sel_Selkirk_Team"]["fields"]["sel_selkirk_team_users"] = array (
  'name' => 'sel_selkirk_team_users',
  'type' => 'link',
  'relationship' => 'sel_selkirk_team_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_USERS_TITLE',
);

<?php
// created: 2014-05-22 00:47:09
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_client_sel_selkirk_project"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_project',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_project',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Client',
  'bean_name' => 'sel_Selkirk_Client',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_PROJECT_FROM_SEL_SELKIRK_CLIENT_TITLE',
);

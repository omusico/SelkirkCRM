<?php
// created: 2014-06-13 11:46:05
$dictionary["sel_Selkirk_Document"]["fields"]["sel_selkirk_document_sel_selkirk_client"] = array (
  'name' => 'sel_selkirk_document_sel_selkirk_client',
  'type' => 'link',
  'relationship' => 'sel_selkirk_document_sel_selkirk_client',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Client',
  'bean_name' => 'sel_Selkirk_Client',
  'vname' => 'LBL_SEL_SELKIRK_DOCUMENT_SEL_SELKIRK_CLIENT_FROM_SEL_SELKIRK_CLIENT_TITLE',
);

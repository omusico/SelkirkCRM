<?php
// created: 2014-06-13 11:46:05
$dictionary["User"]["fields"]["sel_selkirk_team_users"] = array (
  'name' => 'sel_selkirk_team_users',
  'type' => 'link',
  'relationship' => 'sel_selkirk_team_users',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Team',
  'bean_name' => 'sel_Selkirk_Team',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_SEL_SELKIRK_TEAM_TITLE',
  'id_name' => 'sel_selkirk_team_userssel_selkirk_team_ida',
);
$dictionary["User"]["fields"]["sel_selkirk_team_users_name"] = array (
  'name' => 'sel_selkirk_team_users_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_SEL_SELKIRK_TEAM_TITLE',
  'save' => true,
  'id_name' => 'sel_selkirk_team_userssel_selkirk_team_ida',
  'link' => 'sel_selkirk_team_users',
  'table' => 'sel_selkirk_team',
  'module' => 'sel_Selkirk_Team',
  'rname' => 'name',
);
$dictionary["User"]["fields"]["sel_selkirk_team_userssel_selkirk_team_ida"] = array (
  'name' => 'sel_selkirk_team_userssel_selkirk_team_ida',
  'type' => 'link',
  'relationship' => 'sel_selkirk_team_users',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_USERS_TITLE',
);

<?php
 if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

$suitecrm_version      = '7.1.4';
$suitecrm_timestamp    = '2014-09-24 17:00pm';

?>

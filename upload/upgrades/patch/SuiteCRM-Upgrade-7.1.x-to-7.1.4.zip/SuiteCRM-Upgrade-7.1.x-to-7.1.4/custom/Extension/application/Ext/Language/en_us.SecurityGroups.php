<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Security Groups Management';
$app_strings['LBL_LOGIN_AS'] = "Login as ";
$app_strings['LBL_LOGOUT_AS'] = "Logout as ";
$app_strings['LBL_SECURITYGROUP'] = 'Security Group';

?>
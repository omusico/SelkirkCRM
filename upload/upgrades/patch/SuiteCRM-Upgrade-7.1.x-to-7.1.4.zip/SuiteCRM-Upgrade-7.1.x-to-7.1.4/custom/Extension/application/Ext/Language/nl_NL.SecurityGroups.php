<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Security Groepen';
$app_strings['LBL_LOGIN_AS'] = "Log in als ";
$app_strings['LBL_LOGOUT_AS'] = "Log uit als ";
$app_strings['LBL_SECURITYGROUP'] = 'Security Groepen';

?>

<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Управление Группами пользователей';
$app_strings['LBL_LOGIN_AS'] = "Войти как ";
$app_strings['LBL_LOGOUT_AS'] = "Выйти как ";
$app_strings['LBL_SECURITYGROUP'] = 'Управление Группами';
?>


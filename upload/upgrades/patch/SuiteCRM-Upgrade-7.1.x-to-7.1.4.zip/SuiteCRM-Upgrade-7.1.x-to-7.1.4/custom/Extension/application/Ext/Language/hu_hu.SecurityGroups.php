<?php

$app_list_strings["moduleList"]["SecurityGroups"] = 'Biztonsági Csoportok Kezelése';
$app_strings['LBL_LOGIN_AS'] = "Belépés mint ";
$app_strings['LBL_LOGOUT_AS'] = "Kilépés mint ";
$app_strings['LBL_SECURITYGROUP'] = 'Biztonsági Csoportok';

?>

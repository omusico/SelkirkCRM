<?php

$app_list_strings["moduleList"]["SecurityGroups"] = "Gestion des équipes";
$app_strings['LBL_LOGIN_AS'] = "Ouverture comme ";
$app_strings['LBL_LOGOUT_AS'] = "D�connexion comme ";
$app_strings['LBL_SECURITYGROUP'] = 'Gestion des équipe';

?>
<?php
/***CONNECTOR SOURCE***/
$config['name'] = 'Facebook';
$config['properties']['appid'] = '';
$config['properties']['secret'] = '';

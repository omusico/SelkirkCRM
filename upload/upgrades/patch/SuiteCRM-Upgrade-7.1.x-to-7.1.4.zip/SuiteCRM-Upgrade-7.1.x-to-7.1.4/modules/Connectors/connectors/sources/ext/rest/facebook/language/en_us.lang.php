<?php

    if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

    $connector_strings = array (
        //Vardef labels
        'LBL_LICENSING_INFO' => '<table border="0" cellspacing="1"><tr><th valign="top" width="35%" class="dataLabel">Facebook Application Information </th></tr>
                                    <tr><td width="35%" class="dataLabel">You will need to create a facebook application, Get one <a href=https://developers.facebook.com/?ref=pf">here</a>  </td></tr></table>',

        //Configuration labels
        'appid' => 'Facebook App ID ',
        'secret' => 'Facebook App Secret ',
    );

?>
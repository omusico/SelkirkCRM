<?php
/***CONNECTOR SOURCE***/
$config['name'] = 'Twitter';
$config['properties']['consumer_key'] = '';
$config['properties']['consumer_secret'] = '';

<?php
// created: 2014-09-25 12:00:00
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.15',
      1 => '6.5.16',
      2 => '6.5.17',
      3 => '6.5.18',
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SalesAgility',
  'copy_files' => 
  array (
    'from_dir' => 'SuiteCRM-Upgrade-7.1.x-to-7.1.4',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => false,
  'offline_client_applicable' => true,
  'name' => 'SuiteCRM',
  'published_date' => '2014-09-25 12:00:00',
  'type' => 'patch',
  'version' => '7.1.4',
);
?>

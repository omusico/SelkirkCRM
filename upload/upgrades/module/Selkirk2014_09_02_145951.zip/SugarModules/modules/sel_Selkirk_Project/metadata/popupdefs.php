<?php
$popupMeta = array (
    'moduleMain' => 'sel_Selkirk_Project',
    'varName' => 'sel_Selkirk_Project',
    'orderBy' => 'sel_selkirk_project.name',
    'whereClauses' => array (
  'name' => 'sel_selkirk_project.name',
),
    'searchInputs' => array (
  0 => 'sel_selkirk_project_number',
  1 => 'name',
  2 => 'priority',
  3 => 'status',
),
    'listviewdefs' => array (
  'NAME' => 
  array (
    'type' => 'name',
    'link' => true,
    'label' => 'LBL_NAME',
    'width' => '10%',
    'default' => true,
  ),
),
);

<?php
$module_name = 'sel_Student_Project';
$listViewDefs [$module_name] = 
array (
  'NAME' => 
  array (
    'width' => '32%',
    'label' => 'LBL_NAME',
    'default' => true,
    'link' => true,
  ),
  'SCHOOL' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SCHOOL',
    'width' => '10%',
    'default' => true,
  ),
  'PROGRAM' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_PROGRAM',
    'width' => '10%',
    'default' => true,
  ),
  'SUPERVISOR' => 
  array (
    'type' => 'varchar',
    'label' => 'LBL_SUPERVISOR',
    'width' => '10%',
    'default' => true,
  ),
);
?>

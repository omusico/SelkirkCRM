<?php
// created: 2014-06-24 17:18:32
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_partner"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_partner',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_partner',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Partner',
  'bean_name' => 'sel_Selkirk_Partner',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_PARTNER_FROM_SEL_SELKIRK_PARTNER_TITLE',
);

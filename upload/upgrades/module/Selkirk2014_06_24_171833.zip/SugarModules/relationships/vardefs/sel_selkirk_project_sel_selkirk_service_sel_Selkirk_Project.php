<?php
// created: 2014-06-24 17:18:31
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_service"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_service',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_service',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Service',
  'bean_name' => 'sel_Selkirk_Service',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_SERVICE_FROM_SEL_SELKIRK_SERVICE_TITLE',
);

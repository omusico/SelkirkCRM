<?php
// created: 2014-06-24 17:18:32
$dictionary["sel_Selkirk_Business_Case"]["fields"]["sel_selkirk_project_sel_selkirk_business_case"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_business_case',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_business_case',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Project',
  'bean_name' => 'sel_Selkirk_Project',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_BUSINESS_CASE_FROM_SEL_SELKIRK_PROJECT_TITLE',
);

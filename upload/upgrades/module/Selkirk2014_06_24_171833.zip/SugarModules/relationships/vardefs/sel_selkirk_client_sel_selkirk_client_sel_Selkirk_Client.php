<?php
// created: 2014-05-21 16:12:27
$dictionary["sel_Selkirk_Client"]["fields"]["sel_selkirk_client_sel_selkirk_client"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_client',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_client',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Client',
  'bean_name' => 'sel_Selkirk_Client',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_CLIENT_FROM_SEL_SELKIRK_CLIENT_L_TITLE',
);
$dictionary["sel_Selkirk_Client"]["fields"]["sel_selkirk_client_sel_selkirk_client"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_client',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_client',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Client',
  'bean_name' => 'sel_Selkirk_Client',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_CLIENT_FROM_SEL_SELKIRK_CLIENT_R_TITLE',
);

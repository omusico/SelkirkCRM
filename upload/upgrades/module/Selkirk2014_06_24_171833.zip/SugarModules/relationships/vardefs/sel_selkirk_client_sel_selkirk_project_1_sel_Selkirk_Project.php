<?php
// created: 2014-05-23 17:22:54
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_client_sel_selkirk_project_1"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_project_1',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_project_1',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Client',
  'bean_name' => 'sel_Selkirk_Client',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_PROJECT_1_FROM_SEL_SELKIRK_CLIENT_TITLE',
);

<?php
// created: 2014-06-24 17:18:31
$dictionary["User"]["fields"]["sel_selkirk_team_users"] = array (
  'name' => 'sel_selkirk_team_users',
  'type' => 'link',
  'relationship' => 'sel_selkirk_team_users',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Team',
  'bean_name' => 'sel_Selkirk_Team',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_SEL_SELKIRK_TEAM_TITLE',
);

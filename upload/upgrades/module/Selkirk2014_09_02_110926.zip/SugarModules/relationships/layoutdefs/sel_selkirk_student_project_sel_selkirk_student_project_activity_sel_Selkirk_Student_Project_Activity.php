<?php
 // created: 2014-09-02 11:09:22
$layout_defs["sel_Selkirk_Student_Project_Activity"]["subpanel_setup"]['sel_selkirk_student_project_sel_selkirk_student_project_activity'] = array (
  'order' => 100,
  'module' => 'sel_Selkirk_Student_Project',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_SEL_SELKIRK_STUDENT_PROJECT_SEL_SELKIRK_STUDENT_PROJECT_ACTIVITY_FROM_SEL_SELKIRK_STUDENT_PROJECT_TITLE',
  'get_subpanel_data' => 'sel_selkirk_student_project_sel_selkirk_student_project_activity',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);

<?php
 // created: 2012-08-23 23:17:02
$layout_defs["dash_DashboardManager"]["subpanel_setup"]['dash_dashboardmanager_users_1'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'title_key' => 'LBL_DASH_DASHBOARDMANAGER_USERS_1_FROM_USERS_TITLE',
  'get_subpanel_data' => 'dash_dashboardmanager_users_1',
);

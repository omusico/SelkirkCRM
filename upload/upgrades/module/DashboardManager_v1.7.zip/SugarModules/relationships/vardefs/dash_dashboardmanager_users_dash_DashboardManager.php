<?php
// created: 2012-08-23 23:17:02
$dictionary["dash_DashboardManager"]["fields"]["dash_dashboardmanager_users"] = array (
  'name' => 'dash_dashboardmanager_users',
  'type' => 'link',
  'relationship' => 'dash_dashboardmanager_users',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_DASH_DASHBOARDMANAGER_USERS_FROM_USERS_TITLE',
);

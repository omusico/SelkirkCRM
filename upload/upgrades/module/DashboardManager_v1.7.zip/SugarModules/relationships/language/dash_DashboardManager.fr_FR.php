<?php
//THIS FILE IS AUTO GENERATED, DO NOT MODIFY
$mod_strings['LBL_DASH_DASHBOARDBACKUPS_DASH_DASHBOARDMANAGER_FROM_DASH_DASHBOARDBACKUPS_TITLE'] = 'Sauvegardes utilisateur associées';
$mod_strings['LBL_DASH_DASHBOARDMANAGER_USERS_FROM_USERS_TITLE'] = 'Utilisateurs : Page d&#39;accueils vérouillées';
$mod_strings['LBL_DASH_DASHBOARDMANAGER_USERS_1_FROM_USERS_TITLE'] = 'Utilisateurs : Page d&#39;accueil initialisées';
$mod_strings['LBL_DASH_DASHBOARDMANAGER_USERS_2_FROM_USERS_TITLE'] = 'Utilisateurs : Onglets forcés';

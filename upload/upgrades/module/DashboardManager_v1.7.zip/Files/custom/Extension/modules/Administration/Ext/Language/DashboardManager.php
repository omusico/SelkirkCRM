<?php

    //Dashboard Manager
    $mod_strings['LBL_DASHBOARD_MANAGEMENT'] = 'Dashboard Management';
    $mod_strings['LBL_DASHBOARD_MANAGER'] = 'Dashboard Manager';
    $mod_strings['LBL_DASHBOARD_BACKUPS'] = 'Dashboard Backups';
    $mod_strings['LBL_DASHBOARD_MANAGER_DESCRIPTION'] = 'Manage dashboard templates';
    $mod_strings['LBL_DASHBOARD_BACKUPS_DESCRIPTION'] = 'Manage dashboard backups';

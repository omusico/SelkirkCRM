<?php
// created: 2014-07-14 14:05:11
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_team"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_team',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_team',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Team',
  'bean_name' => 'sel_Selkirk_Team',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_TEAM_FROM_SEL_SELKIRK_TEAM_TITLE',
);

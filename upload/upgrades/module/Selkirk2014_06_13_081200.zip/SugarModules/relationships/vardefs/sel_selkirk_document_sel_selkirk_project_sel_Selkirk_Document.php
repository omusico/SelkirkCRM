<?php
// created: 2014-06-13 08:11:58
$dictionary["sel_Selkirk_Document"]["fields"]["sel_selkirk_document_sel_selkirk_project"] = array (
  'name' => 'sel_selkirk_document_sel_selkirk_project',
  'type' => 'link',
  'relationship' => 'sel_selkirk_document_sel_selkirk_project',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Project',
  'bean_name' => 'sel_Selkirk_Project',
  'vname' => 'LBL_SEL_SELKIRK_DOCUMENT_SEL_SELKIRK_PROJECT_FROM_SEL_SELKIRK_PROJECT_TITLE',
);

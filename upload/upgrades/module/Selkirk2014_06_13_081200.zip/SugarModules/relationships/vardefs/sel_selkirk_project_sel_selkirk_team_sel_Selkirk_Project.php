<?php
// created: 2014-06-13 08:11:59
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_team"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_team',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_team',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Team',
  'bean_name' => false,
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_TEAM_FROM_SEL_SELKIRK_TEAM_TITLE',
  'id_name' => 'sel_selkirk_project_sel_selkirk_teamsel_selkirk_team_idb',
);
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_team_name"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_team_name',
  'type' => 'relate',
  'source' => 'non-db',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_TEAM_FROM_SEL_SELKIRK_TEAM_TITLE',
  'save' => true,
  'id_name' => 'sel_selkirk_project_sel_selkirk_teamsel_selkirk_team_idb',
  'link' => 'sel_selkirk_project_sel_selkirk_team',
  'table' => 'sel_selkirk_team',
  'module' => 'sel_Selkirk_Team',
  'rname' => 'name',
);
$dictionary["sel_Selkirk_Project"]["fields"]["sel_selkirk_project_sel_selkirk_teamsel_selkirk_team_idb"] = array (
  'name' => 'sel_selkirk_project_sel_selkirk_teamsel_selkirk_team_idb',
  'type' => 'link',
  'relationship' => 'sel_selkirk_project_sel_selkirk_team',
  'source' => 'non-db',
  'reportable' => false,
  'side' => 'left',
  'vname' => 'LBL_SEL_SELKIRK_PROJECT_SEL_SELKIRK_TEAM_FROM_SEL_SELKIRK_TEAM_TITLE',
);

<?php
// created: 2014-06-13 08:12:00
$dictionary["sel_Selkirk_Client"]["fields"]["sel_selkirk_client_sel_selkirk_service"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_service',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_service',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Service',
  'bean_name' => 'sel_Selkirk_Service',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_SERVICE_FROM_SEL_SELKIRK_SERVICE_TITLE',
);

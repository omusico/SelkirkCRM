<?php
// created: 2014-06-13 08:12:00
$dictionary["sel_Selkirk_Client"]["fields"]["sel_selkirk_client_sel_selkirk_contact"] = array (
  'name' => 'sel_selkirk_client_sel_selkirk_contact',
  'type' => 'link',
  'relationship' => 'sel_selkirk_client_sel_selkirk_contact',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Contact',
  'bean_name' => 'sel_Selkirk_Contact',
  'vname' => 'LBL_SEL_SELKIRK_CLIENT_SEL_SELKIRK_CONTACT_FROM_SEL_SELKIRK_CONTACT_TITLE',
);

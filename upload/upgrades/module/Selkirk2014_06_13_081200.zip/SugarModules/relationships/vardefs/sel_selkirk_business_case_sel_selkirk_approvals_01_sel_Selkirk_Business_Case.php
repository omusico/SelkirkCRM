<?php
// created: 2014-06-11 13:07:41
$dictionary["sel_Selkirk_Business_Case"]["fields"]["sel_selkirk_business_case_sel_selkirk_approvals_01"] = array (
  'name' => 'sel_selkirk_business_case_sel_selkirk_approvals_01',
  'type' => 'link',
  'relationship' => 'sel_selkirk_business_case_sel_selkirk_approvals_01',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Approvals_01',
  'bean_name' => 'sel_Selkirk_Approvals_01',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_BUSINESS_CASE_SEL_SELKIRK_APPROVALS_01_FROM_SEL_SELKIRK_APPROVALS_01_TITLE',
);

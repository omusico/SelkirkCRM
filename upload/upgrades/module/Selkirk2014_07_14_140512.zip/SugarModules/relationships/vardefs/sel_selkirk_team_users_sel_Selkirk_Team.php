<?php
// created: 2014-07-14 14:05:10
$dictionary["sel_Selkirk_Team"]["fields"]["sel_selkirk_team_users"] = array (
  'name' => 'sel_selkirk_team_users',
  'type' => 'link',
  'relationship' => 'sel_selkirk_team_users',
  'source' => 'non-db',
  'module' => 'Users',
  'bean_name' => 'User',
  'vname' => 'LBL_SEL_SELKIRK_TEAM_USERS_FROM_USERS_TITLE',
);

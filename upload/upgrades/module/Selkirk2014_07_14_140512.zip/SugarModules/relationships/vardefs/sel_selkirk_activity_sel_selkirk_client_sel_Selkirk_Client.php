<?php
// created: 2014-06-05 17:44:34
$dictionary["sel_Selkirk_Client"]["fields"]["sel_selkirk_activity_sel_selkirk_client"] = array (
  'name' => 'sel_selkirk_activity_sel_selkirk_client',
  'type' => 'link',
  'relationship' => 'sel_selkirk_activity_sel_selkirk_client',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Activity',
  'bean_name' => 'sel_Selkirk_Activity',
  'side' => 'right',
  'vname' => 'LBL_SEL_SELKIRK_ACTIVITY_SEL_SELKIRK_CLIENT_FROM_SEL_SELKIRK_ACTIVITY_TITLE',
);

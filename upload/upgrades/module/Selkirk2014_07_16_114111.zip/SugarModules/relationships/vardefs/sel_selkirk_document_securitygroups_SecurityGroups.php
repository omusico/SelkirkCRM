<?php
// created: 2014-07-16 11:41:09
$dictionary["SecurityGroup"]["fields"]["sel_selkirk_document_securitygroups"] = array (
  'name' => 'sel_selkirk_document_securitygroups',
  'type' => 'link',
  'relationship' => 'sel_selkirk_document_securitygroups',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Document',
  'bean_name' => 'sel_Selkirk_Document',
  'vname' => 'LBL_SEL_SELKIRK_DOCUMENT_SECURITYGROUPS_FROM_SEL_SELKIRK_DOCUMENT_TITLE',
);

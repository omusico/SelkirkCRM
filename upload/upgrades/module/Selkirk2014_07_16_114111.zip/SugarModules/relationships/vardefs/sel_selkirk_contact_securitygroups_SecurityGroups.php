<?php
// created: 2014-07-16 11:41:09
$dictionary["SecurityGroup"]["fields"]["sel_selkirk_contact_securitygroups"] = array (
  'name' => 'sel_selkirk_contact_securitygroups',
  'type' => 'link',
  'relationship' => 'sel_selkirk_contact_securitygroups',
  'source' => 'non-db',
  'module' => 'sel_Selkirk_Contact',
  'bean_name' => 'sel_Selkirk_Contact',
  'vname' => 'LBL_SEL_SELKIRK_CONTACT_SECURITYGROUPS_FROM_SEL_SELKIRK_CONTACT_TITLE',
);

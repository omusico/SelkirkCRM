<?php
// created: 2014-07-16 11:41:10
$dictionary["sel_Selkirk_Business_Case"]["fields"]["sel_selkirk_business_case_securitygroups"] = array (
  'name' => 'sel_selkirk_business_case_securitygroups',
  'type' => 'link',
  'relationship' => 'sel_selkirk_business_case_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_SEL_SELKIRK_BUSINESS_CASE_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);

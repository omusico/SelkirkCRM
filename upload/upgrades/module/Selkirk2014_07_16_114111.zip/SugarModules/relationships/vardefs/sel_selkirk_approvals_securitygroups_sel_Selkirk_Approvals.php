<?php
// created: 2014-07-16 11:41:10
$dictionary["sel_Selkirk_Approvals"]["fields"]["sel_selkirk_approvals_securitygroups"] = array (
  'name' => 'sel_selkirk_approvals_securitygroups',
  'type' => 'link',
  'relationship' => 'sel_selkirk_approvals_securitygroups',
  'source' => 'non-db',
  'module' => 'SecurityGroups',
  'bean_name' => 'SecurityGroup',
  'vname' => 'LBL_SEL_SELKIRK_APPROVALS_SECURITYGROUPS_FROM_SECURITYGROUPS_TITLE',
);
